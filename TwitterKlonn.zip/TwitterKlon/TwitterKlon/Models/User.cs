﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TwitterKlon.Models // Passe den Namespace an dein Projekt an
{
    /// <summary>
    /// Repräsentiert einen Benutzer in der Datenbank (Tabelle: Users).
    /// </summary>
    public class User
    {
        [Key] // Definiert UserID als Primärschlüssel
        public int UserID { get; set; }

        [Required(ErrorMessage = "Ein Name ist erforderlich.")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Eine E-Mail-Adresse ist erforderlich.")]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; }

        [Required]
        public string PasswordHash { get; set; }

        // Navigationseigenschaften: Ein User kann viele Posts und viele Likes haben.
        public virtual ICollection<Post> Posts { get; set; }
        public virtual ICollection<Like> Likes { get; set; }
    }
}