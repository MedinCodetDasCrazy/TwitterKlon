﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TwitterKlon.Models;

public class Like
{
    [Key]
    public int LikeID { get; set; }

    // Fremdschlüssel
    public int UserID { get; set; }
    public int PostID { get; set; }

    // Navigationseigenschaften
    [ForeignKey("UserID")]
    public virtual User User { get; set; }

    [ForeignKey("PostID")]
    public virtual Post Post { get; set; }
}