﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TwitterKlon.Models;

public class Post
{
    [Key]
    public int PostID { get; set; }

    [Required(ErrorMessage = "Der Post darf nicht leer sein.")]
    [StringLength(280)]
    public string Content { get; set; }

    [Required]
    public DateTime CreatedAt { get; set; }

    // Fremdschlüssel-Beziehung zu User
    public int UserID { get; set; }

    // Navigationseigenschaft: Jeder Post gehört zu genau einem User.
    [ForeignKey("UserID")]
    public virtual User User { get; set; }

    // Navigationseigenschaft: Ein Post kann viele Likes haben.
    public virtual ICollection<Like> Likes { get; set; }
}