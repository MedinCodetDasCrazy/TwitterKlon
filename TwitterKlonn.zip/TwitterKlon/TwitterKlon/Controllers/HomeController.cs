using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TwitterKlon.Data;
using TwitterKlon.Models;
using TwitterKlon.ViewModel;

namespace TwitterKlon.Controllers
{
    public class HomeController : Controller
    {
        private readonly TwitterDbContext _context;

        public HomeController(TwitterDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var posts = await _context.Posts
                                      .Include(p => p.User)
                                      .Include(p => p.Likes)
                                      .OrderByDescending(p => p.CreatedAt)
                                      .ToListAsync();

            var viewModel = new DashboardViewModel
            {
                AllPosts = posts,
                NewPost = new CreatePostViewModel()
            };

            return View(viewModel);
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        // Die Methode nimmt jetzt NUR das ViewModel f�r den neuen Post entgegen.
        public async Task<IActionResult> CreatePost(CreatePostViewModel model)
        {
            // Die Validierung ist jetzt korrekt und einfach.
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

                var post = new Post
                {
                    Content = model.Content,
                    CreatedAt = DateTime.UtcNow,
                    UserID = int.Parse(userId)
                };

                _context.Posts.Add(post);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            // WICHTIG: Wenn die Validierung fehlschl�gt, m�ssen wir das
            // komplette Dashboard-Modell neu erstellen, damit die Seite korrekt angezeigt wird.
            var posts = await _context.Posts
                                       .Include(p => p.User)
                                       .OrderByDescending(p => p.CreatedAt)
                                       .ToListAsync();
            var dashboardViewModel = new DashboardViewModel
            {
                AllPosts = posts,
                NewPost = model // Wir �bergeben das fehlerhafte Modell, um die Fehlermeldung anzuzeigen.
            };

            return View("Index", dashboardViewModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
