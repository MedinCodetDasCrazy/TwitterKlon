﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using TwitterKlon.Data;
using TwitterKlon.ViewModel;
namespace TwitterKlon.Controllers
{
    public class ProfileController : Controller
    {
        private readonly TwitterDbContext _context;

        public ProfileController(TwitterDbContext context)
        {
            _context = context;
        }

        // GET: /Profile/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound(); // Wenn keine ID übergeben wird, Fehler anzeigen.
            }

            // 1. Finde den Benutzer anhand der ID.
            var user = await _context.Users.FindAsync(id);

            if (user == null)
            {
                return NotFound(); // Wenn kein Benutzer mit dieser ID existiert, Fehler anzeigen.
            }

            // 2. Lade nur die Posts dieses Benutzers, inklusive der Like-Informationen.
            var userPosts = await _context.Posts
                .Where(p => p.UserID == id)
                .Include(p => p.Likes) // Wichtig für die Zählung!
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();

            // 3. Erstelle den ViewModel und berechne die Statistiken.
            var viewModel = new ProfileViewModel
            {
                ProfileUser = user,
                UserPosts = userPosts,
                TotalPosts = userPosts.Count(),
                TotalLikesReceived = userPosts.Sum(p => p.Likes.Count()) // Summiert die Likes aller Posts
            };

            return View(viewModel);
        }
    }
}
