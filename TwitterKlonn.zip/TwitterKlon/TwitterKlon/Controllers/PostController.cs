﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TwitterKlon.Data;
using TwitterKlon.Models;

namespace TwitterKlon.Controllers
{
    [Authorize] // Alle Aktionen in diesem Controller erfordern eine Anmeldung.
    public class PostController : Controller
    {
        private readonly TwitterDbContext _context;

        public PostController(TwitterDbContext context)
        {
            _context = context;
        }

        // POST: /Post/ToggleLike/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleLike(int id)
        {
            // 1. Die ID des aktuell angemeldeten Benutzers holen.
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

            // 2. Suchen, ob dieser Benutzer diesen Post bereits geliked hat.
            var existingLike = await _context.Likes
                .FirstOrDefaultAsync(l => l.PostID == id && l.UserID == userId);

            if (existingLike != null)
            {
                // 3a. Wenn ein Like existiert -> entfernen (Unlike).
                _context.Likes.Remove(existingLike);
            }
            else
            {
                // 3b. Wenn kein Like existiert -> neuen Like erstellen.
                var newLike = new Like
                {
                    PostID = id,
                    UserID = userId
                };
                _context.Likes.Add(newLike);
            }

            // 4. Änderungen in der Datenbank speichern.
            await _context.SaveChangesAsync();

            // 5. Zurück zur Startseite weiterleiten.
            return RedirectToAction("Index", "Home");
        }
    }
}
