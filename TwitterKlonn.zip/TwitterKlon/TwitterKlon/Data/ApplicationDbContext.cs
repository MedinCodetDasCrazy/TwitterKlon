﻿using Microsoft.EntityFrameworkCore;
using TwitterKlon.Models; // Wichtig, damit wir unsere Models hier verwenden können
using TwitterKlon.Data;

namespace TwitterKlon.Data
{
    /// <summary>
    /// Der DbContext ist die Brücke zwischen unseren C#-Klassen (Models)
    /// und der Datenbank. Er verwaltet die Verbindung und die Datenabfragen.
    /// </summary>
    public class TwitterDbContext : DbContext
    {
        // Der Konstruktor ist notwendig, um die Konfiguration (z.B. den Connection String)
        // an die Basisklasse DbContext weiterzugeben.
        public TwitterDbContext(DbContextOptions<TwitterDbContext> options) : base(options)
        {
        }

        // Jedes DbSet<T> repräsentiert eine Tabelle in der Datenbank.
        public DbSet<User> Users { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<Like> Likes { get; set; }

        /// <summary>
        /// Diese Methode wird von Entity Framework aufgerufen, wenn das Datenbankmodell
        /// erstellt wird. Hier können wir zusätzliche Konfigurationen vornehmen.
        /// </summary>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Regel 1: Die E-Mail-Adresse eines Benutzers muss einzigartig sein.
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // Regel 2: Lösen des "multiple cascade paths"-Problems.
            // Wenn ein User gelöscht wird, wird die Verknüpfung zum Like nur entfernt,
            // aber es wird keine Kaskadenlöschung ausgelöst.
            modelBuilder.Entity<User>()
                .HasMany(u => u.Likes)
                .WithOne(l => l.User)
                .HasForeignKey(l => l.UserID)
                .OnDelete(DeleteBehavior.Restrict); // Wichtige Änderung!

            // Regel 3: Wenn ein Post gelöscht wird, werden alle zugehörigen Likes mitgelöscht.
            // Dies ist der primäre Löschpfad für Likes.
            modelBuilder.Entity<Post>()
                .HasMany(p => p.Likes)
                .WithOne(l => l.Post)
                .HasForeignKey(l => l.PostID)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
