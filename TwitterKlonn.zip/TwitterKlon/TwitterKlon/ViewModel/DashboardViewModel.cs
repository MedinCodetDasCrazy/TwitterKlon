﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using TwitterKlon.Models;


namespace TwitterKlon.ViewModel
{
    public class DashboardViewModel
    {
        // Eine Eigenschaft, die das Formular-Model enthält.
        public CreatePostViewModel NewPost { get; set; }

        // Eine Liste, die alle existierenden Posts für die Anzeige enthält.
        public IEnumerable<Post> AllPosts { get; set; }
    }
}
