﻿using System.ComponentModel.DataAnnotations; 

namespace TwitterKlon.ViewModel
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Bitte geben Sie Ihren Namen ein.")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Bitte geben Sie Ihre E-Mail-Adresse ein.")]
        [EmailAddress(ErrorMessage = "Bitte geben Sie eine gültige E-Mail-Adresse ein.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Bitte geben Sie ein Passwort ein.")]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "Das Passwort muss mindestens 6 Zeichen lang sein.", MinimumLength = 6)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Bestätigen Sie das Passwort")]
        [Compare("Password", ErrorMessage = "Die Passwörter stimmen nicht überein.")]
        public string ConfirmPassword { get; set; }
    }
}
