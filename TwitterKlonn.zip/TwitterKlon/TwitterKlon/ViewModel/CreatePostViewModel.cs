﻿// In ViewModels/CreatePostViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace TwitterKlon.ViewModel
{
    public class CreatePostViewModel
    {
        [Required(ErrorMessage = "Der Post darf nicht leer sein.")]
        [StringLength(280)]
        public string Content { get; set; }
    }
}