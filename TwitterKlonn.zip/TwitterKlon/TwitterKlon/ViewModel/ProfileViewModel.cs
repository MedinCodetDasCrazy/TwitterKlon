﻿using System.Collections.Generic;
using TwitterKlon.Models;

namespace TwitterKlon.ViewModel
{
    public class ProfileViewModel
    {
        // Der Benutzer, dessen Profil angezeigt wird.
        public User ProfileUser { get; set; }

        // Eine Liste, die nur die Posts dieses Benutzers enthält.
        public IEnumerable<Post> UserPosts { get; set; }

        // Statistik: Gesamtzahl der Posts des Benutzers.
        public int TotalPosts { get; set; }

        // Statistik: Gesamtzahl der Likes, die alle Posts des Benutzers erhalten haben.
        public int TotalLikesReceived { get; set; }
    }
}
